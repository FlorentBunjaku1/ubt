public class StringTest
{
	public static void main(String [] arg){
		String a = "UaT";
		String b = new String("UBT");
		
		if(a == b) {
			System.out.println("a e barabarte me b (REFERENCE)");
		}
		else {
			System.out.println("a JO e barabarte me b (REFERENCE)");
		}
		
		if(a.equals(b)) {
			System.out.println("a e barabarte me b (EQUALS)");
		}
		else {
			System.out.println("a JO e barabarte me b (EQUALS)");
		}
		
		if(a.equalsIgnoreCase(b)) {
			System.out.println("a e barabarte me b (EQUALS IGNORE CASE)");
		}
		else {
			System.out.println("a JO e barabarte me b (EQUALS IGNORE CASE)");
		}		
	}
}
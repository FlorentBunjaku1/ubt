public class Studenti {
	private int id;
	private String emri;	
	
	public Studenti(int i, String e){
		id = i;
		emri = e;
	}
	
	public int getId(){
		return id;
	}
	
	public String getEmri(){
		return emri;
	}
	
	public void setEmri(String e) {
		emri = e;
	}

	@Override
	public boolean equals(Object obj){
		if(obj instanceof Studenti) {
			Studenti std = (Studenti)obj;
			return id == std.getId();
		}
		return false;
	}
}
public class CharTest
{
	public static void main(String [] arg)
	{
		char ch = '0';
		
		System.out.println(ch+" e ka shifren: "+(int)ch);
		if(ch >= '0' && ch <= '9')
		{
			System.out.println(ch+" eshte numer");
		}
		else
		{
			System.out.println(ch+" NUK eshte numer");
		}
		
		char c = 75;
		System.out.println(c+" e ka shifren: "+(int)c);
		
		int x = 'D';
		System.out.println(x+" reprezenton simbolin: "+(char)x);
	}
}
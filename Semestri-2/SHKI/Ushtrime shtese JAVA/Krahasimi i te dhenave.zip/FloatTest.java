public class FloatTest
{
	public static void main(String [] arg) {
		float f1 = 1.2f;
		float f2 = 1.1f;
		
		System.out.println(f1+" - "+f2+" = "+(f1-f2));
		if(f1 - f2 == 0.1){
			System.out.println("Resultati i pritur");
		}
		else {
			System.out.println("Resultati i PApritur");
		}
	}
}
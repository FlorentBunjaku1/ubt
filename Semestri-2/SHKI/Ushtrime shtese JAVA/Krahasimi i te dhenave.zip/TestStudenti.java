import java.util.Scanner;

public class TestStudenti {
	public static void main(String [] arg) {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Shtyp emrin e studentit: ");
		String emri = scan.nextLine();
		
		System.out.print("Shtyp ID-ne e studentit: ");
		int id = scan.nextInt();
		
		Studenti s1 = new Studenti(id, emri);
		
		
		scan.nextLine();
		
		System.out.print("Shtyp emrin e studentit tjeter: ");
		emri = scan.nextLine();
		
		System.out.print("Shtyp ID-ne e studentit tjeter: ");
		id = scan.nextInt();
		
		Studenti s2 = new Studenti(id, emri);
		
		
		
		System.out.printf("Studenti me id: %d ka emrin %s%n",s1.getId(),s1.getEmri());
		System.out.printf("Studenti me id: %d ka emrin %s%n",s2.getId(),s2.getEmri());
		
		/*s1 = s2;
		System.out.println("TANI s1:"+s1);
		System.out.println("TANI s2:"+s2);
		*/
		
		if(s1.equals(s2)) {
			System.out.println("Studentet jane te barabarte");
		} else {
			System.out.println("Studentet NUK jane te barabarte");
		}
		
		
		if(s1.equals(scan)) {
			System.out.println("Studenti eshte i barabarte me Scanner");
		} else {
			System.out.println("Studenti NUK eshte i barabarte me Scanner");
		}
	}
}
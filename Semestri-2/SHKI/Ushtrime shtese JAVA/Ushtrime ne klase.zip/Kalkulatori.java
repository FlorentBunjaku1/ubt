public class Kalkulatori
{
	public static void main(String [] arg) {
		int x = 5;
		int y = 2;
		System.out.println(x+" + "+y+" = "+(x+y));
		System.out.println(x+" - "+y+" = "+(x-y));
		System.out.println(x+" * "+y+" = "+(x*y));
		System.out.println(x+" / "+y+" = "+(x/y));
		System.out.println(x+" % "+y+" = "+(x%y));
		
	}
}
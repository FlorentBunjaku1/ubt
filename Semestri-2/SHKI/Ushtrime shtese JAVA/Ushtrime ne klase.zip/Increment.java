public class Increment{
	public static void main(String [] arg)
	{
		/*int x = 3, y = 6;
		int z = --x + ++y % x++ * y--;
		System.out.println("Z = "+z);
		System.out.println("X = "+x);
		System.out.println("Y = "+y);*/
		
		/*int x = 4, y = 6;
		int z = --x + y-- * ++x % y;
		System.out.println("Z = "+z);
		System.out.println("X = "+x);
		System.out.println("Y = "+y);*/
		
		/*int x = 11, y = 2;
		int z = --x - x / --y % x;
		System.out.println("Z = "+z);
		System.out.println("X = "+x);
		System.out.println("Y = "+y);*/
		
		/*
		int x=3, y=7;
		int z= --x + y++ / x++ % --y;
		System.out.println("Z eshte " + z);
		System.out.println("X = " + x);
		System.out.println("Y = " + y);*/
		
		int x = 9;
		int y = 5;
		int z = x-- % y++ - y;		
		System.out.println("z = " + z);
		System.out.println("X = " + x);
		System.out.println("Y = " + y);
	}
}
public class Universiteti {
	public static void main(String [] arg){
		Fakulteti shk = new Fakulteti("Shkenca Kompjuterike", 13);
		Studenti s1 = new Studenti(12345, "Filanja");
		shk.shtoStudentin(s1);
		shk.shtoStudentin(new Studenti(12346, "Filani"));
		shk.shtoStudentin(new Studenti(12347, "Deme"));
		shk.shtoStudentin(new Studenti(12348, "Alia"));
		shk.shtoStudentin(new Studenti(12345, "Filani"));
		System.out.println("Kapaciteti: "+shk.kapaciteti()+", vende te lira: "+shk.vendeTeLira());
		//System.out.println(shk);
		System.out.println("Studenti me emrin e pare: "+shk.gjejStudentinMeEmrinPare());
	}
}
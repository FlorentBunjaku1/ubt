public class Studenti implements Comparable<Studenti>{
	private int id;
	private String emri;
	
	public Studenti(int i, String e){
		id = i;
		emri = e;
	}
	
	public Studenti(String e, int i){
		id = i;
		emri = e;
	}
	
	public int getId(){
		return id;
	}
	
	public String getEmri(){
		return emri;
	}
	
	public void setEmri(String e){
		emri = e;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Studenti) {
			Studenti s = (Studenti)obj;
			return id == s.id;
		}
		return false;
	}
	
	@Override
	public String toString(){
		return id+": "+emri;
	}
	
	@Override
	public int compareTo(Studenti std) {
		return id - std.getId(); //Renditja sipas IDse 
		//return emri.compareToIgnoreCase(std.getEmri()); //Renditja sipas emrit - nga e para 
		//return std.getEmri().compareToIgnoreCase(emri); //Renditja sipas emrit - nga e fundit 
	}
}

import java.util.Arrays;

public class Fakulteti
{
	private String emri;
	private Studenti [] studentet;
	private int pozita;
	
	public Fakulteti(String e, int nrStudenteve) {
		emri = e;
		studentet = new Studenti[nrStudenteve];
	}
	
	public boolean shtoStudentin(Studenti std) {
		if(std == null){
			System.out.println("Studenti eshte null");
			return false;
		}
		
		if(pozita == studentet.length) {
			System.out.println("Nuk ka vend: "+std);
			return false;
		}
		
		if(contains(std)){
			System.out.println(std+" ekziston!!");	
			return false;
		}
		
		studentet[pozita++] = std;
		return true;
	}
	
	private boolean contains(Studenti std){
		for(int i=0; i < pozita; i++){
			if(studentet[i].equals(std)){
				return true;
			}
		}
		return false;
	}
	
	public Studenti gjejStudentinMeId(int id){
		for(int i=0; i < pozita; i++){
			if(studentet[i].getId() == id){
				return studentet[i];
			}
		}
		return null;
	}	
	
	public Studenti gjejStudentinMeEmerTePare(){
		Studenti s = null;
		for(int i=0; i<pozita; i++) {
			//if(i == 0 || studentet[i].getEmri().compareToIgnoreCase(s.getEmri()) < 0) {
			if(i == 0 || studentet[i].compareTo(s) < 0) {
				s = studentet[i];
			}
		}
		return s;
	}
	
	public Studenti gjejStudentinMeEmrinPare(){
		Studenti [] stds = Arrays.copyOf(studentet, pozita);
		Arrays.sort(stds);
		return stds[0];		
	}
	
	public int kapaciteti(){
		return pozita;
	}
	
	public int vendeTeLira(){
		return studentet.length - pozita;
	}
	
	/*@Override
	public String toString(){
		String str = emri;
		str +="\n[";
		for(int i=0; i < pozita; i++){ //for loop
			str += studentet[i];
			if(i < pozita - 1){
				str +=", ";
			}
		}
		str +="]";
		return str;
	}*/
	
	/*@Override
	public String toString(){
		String str = emri;
		str +="\n[";
		for(Studenti studenti : studentet){
			if(studenti != null) {	//foreach loop
				str += studenti +", ";
			}			
		}
		str +="]";
		return str;
	}*/
	
	@Override
	public String toString(){ //perdorimi i klases Arrays
		String str = emri;
		str +="\n"+Arrays.toString(Arrays.copyOf(studentet, pozita));
		return str;
	}
	
	public void print(){
		System.out.println(emri+"\n------------------------");
		for(int i=0; i<studentet.length; i++){
			System.out.println(studentet[i]);
		}
	}
	
	public void prittyPrint(){
		System.out.print(emri+"\n------------------------\n[");
		for(int i=0; i<pozita; i++){
			System.out.print(studentet[i]);
			if(i < pozita - 1){
				System.out.print(", ");
			}
		}
		System.out.println("]");
	}
	
	public void printArrays(){
		System.out.println(emri+"\n------ARRAYS------------------");
		System.out.println(Arrays.toString(Arrays.copyOf(studentet, pozita)));
		
	}
}

public class Provider {
	private String emri;
	private Shfrytezuesi [] shfrytezuesit;
	private int index;
	
	public Provider(String e, int nr) {
		emri = e;
		shfrytezuesit = new Shfrytezuesi[nr];
	}
	
	public String shtoShfrytezuesin(Shfrytezuesi user) {
		if(user == null){
			return "ERROR:Shfrytezuesi eshte NULL";
		}
		
		if(index == shfrytezuesit.length){
			return "ERROR: Nuk ka vend per: "+user.getKodi();
		}
		
		if(contains(user)){
			return "ERROR: Ekziston ne liste: "+user.getKodi();
		}
		
		shfrytezuesit[index++] = user;
		return "SUKSES: U shtua shfrytezuesi: "+user.getKodi();
	}
	
	private boolean contains(Shfrytezuesi user) {
		for(int i=0; i<index; i++){
			if(shfrytezuesit[i].equals(user)){
				return true;
			}
		}
		return false;
	}
	
	public boolean shkarko(Shfrytezuesi user, String fromIp, int madhesia) {
		/*if(contains(user)){
			return user.shkarkoTeDhena(fromIp, madhesia);
		}
		return false;*/
		return contains(user) ? user.shkarkoTeDhena(fromIp, madhesia) : false;
	} 
	
	public Shfrytezuesi maxShkarkimi (){
		Shfrytezuesi maxUser = null;
		for(int i=0; i<index; i++){
			Shfrytezuesi user = shfrytezuesit[i];
			if(i == 0 || user.getTeShpenzuara() > maxUser.getTeShpenzuara() || 
			(user.getTeShpenzuara() == maxUser.getTeShpenzuara() && user.getLimiti() > maxUser.getLimiti())){
				maxUser = user;
			}
		}
		return maxUser;
	}
	
	public void shfletoShkarkimet (){
		for(int i=0; i<index; i++){
			Shfrytezuesi user = shfrytezuesit[i];
			System.out.println(user+"\n-----------------\n"+user.getShkarkimet());
		}
	}
	
	public static void main(String [] arg) {
		Provider prv = new Provider("UBT Net", 10);
		Shfrytezuesi user = new Shfrytezuesi("AB0001", true, "192.168.0.25", 30);
		System.out.println(prv.shtoShfrytezuesin(user));
		System.out.println(prv.shtoShfrytezuesin(new Shfrytezuesi("AB0001", false, "192.168.0.45", 20)));
		System.out.println(prv.shtoShfrytezuesin(new Shfrytezuesi("AB0022", false, "192.168.1.45", 20)));		
		prv.shkarko(user, "192.168.0.45", 10);
		prv.shkarko(user, "192.168.1.45", 10);
		prv.shkarko(user, "192.168.0.25", 10);
		prv.shkarko(user, "192.168.1.25", 50);
		System.out.println("MAX = "+prv.maxShkarkimi());
		System.out.println();
		prv.shfletoShkarkimet();
	}
}

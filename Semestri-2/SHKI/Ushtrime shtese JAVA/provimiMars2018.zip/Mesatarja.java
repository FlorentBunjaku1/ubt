import java.util.Scanner;

public class Mesatarja {
	public static void main(String [] arg){
		Scanner scan = new Scanner(System.in);
		int length = 0;
		System.out.print("Shtyp madhesine e vargut (>=15): ");
		while(!scan.hasNextInt() || (length = scan.nextInt()) < 15) {
			scan.nextLine();
			System.out.print("Shtyp madhesine e vargut (>=15): ");
		}
		
		double [] vargu = new double[length];
		
		for(int i=0; i<vargu.length; ){
			System.out.print("Shtyp double (-550 ... 550): ");
			double vlera = scan.nextDouble();
			if(vlera >= -550 && vlera <= 550) {
				vargu[i++] = vlera;				
			}
		}
		
		double [] rezultati = kalkuloMesataren(vargu);
		System.out.printf("Negativ: %f, pozitiv: %f, total: %f%n",rezultati[0],rezultati[1],rezultati[2]);
	}
	
	private static double[] kalkuloMesataren(double [] arr) {
		int sumNegativ = 0;
		int sumPozitiv = 0;
		//int sumTotal = 0;
		for(double vlera : arr){
			int val = (int)vlera;
			//sumTotal += val;
			if(val < 0) {
				sumNegativ += val;
			} else if (val > 0) {
				sumPozitiv += val;
			}
		}
		return new double[] {
			(double)sumNegativ/arr.length,
			(double)sumPozitiv/arr.length,
			//(double)sumTotal/arr.length
			(double)(sumPozitiv+sumNegativ)/arr.length
		};	
	}
}
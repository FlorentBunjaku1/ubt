import java.util.Scanner;

public class NumeroShkronjat {
	public static void main(String [] arg){
		Scanner scan = new Scanner(System.in);
		final String SENTINEL = "END";
		int countTotal = 0; //te gjitha fjalite
		int count = 0; //fjalite qe e plotesojne kushtin
		System.out.printf("Shtyp tekst ose %s per fund: ", SENTINEL);
		String fjalia = scan.nextLine();
		while(!fjalia.equals(SENTINEL)){
			countTotal++;
			if(numero(fjalia)){
				count++;
			}
			System.out.printf("Shtyp tekst ose %s per fund: ", SENTINEL);
			fjalia = scan.nextLine();
		}
		
		if(countTotal == 0){
			System.out.println("Nuk u shtyp fare tekst");
		} else {
			System.out.println("Jane shtypur "+countTotal+" fjali dhe "+count+" prej tyre plotesojne kushtin");
		}
	}
	
	//se paku dy fjale e plotesojne kushtin e kerkuar
	private static boolean numero(String str){
		String [] fjalet = str.split(" ");
		if(fjalet.length <= 10) {
			int count = 0;
			for(String fjala : fjalet) {
				if(fjala.length() == 6 && str.toLowerCase().charAt(fjala.length()-2) == 'a'){
				//if(fjala.length() == 6 && str.toLowerCase().charAt(4) == 'a'){	
					count++;
					if(count == 2){
						return true;
					}
				}
			}
		}
		return false;
	}
	
	//se fix dy fjale e plotesojne kushtin e kerkuar
	private static boolean numeroFix(String str){
		String [] fjalet = str.split(" ");
		int count = 0;
		if(fjalet.length <= 10) {
			for(String fjala : fjalet) {
				if(fjala.length() == 6 && str.toLowerCase().charAt(fjala.length()-2) == 'a'){
					count++;				
				}
			}
		}
		return count == 2;
	}
}
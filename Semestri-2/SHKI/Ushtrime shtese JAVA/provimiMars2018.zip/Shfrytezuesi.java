public class Shfrytezuesi {
	private String kodi;
	private boolean premium;
	private String ip;
	private double limiti;
	private String shkarkimet = "";
	private double teShpenzuara;
	
	public Shfrytezuesi(String k, boolean p, String i, double l){
		kodi = k;
		premium = p;
		ip = i;
		limiti = l;
	}
	
	public String getKodi(){
		return kodi;
	}
	
	public boolean getPremium(){
		return premium;
	}
	
	public String getIp(){
		return ip;
	}
	
	public double getLimiti(){
		return limiti;
	}
	
	public void setLimiti(double l) {
		limiti = l;
	}
	
	public double getTeShpenzuara(){
		return teShpenzuara;
	}
	
	public String getShkarkimet(){
		return shkarkimet;
	}
	
	public boolean shkarkoTeDhena (String fromIp, int madhesia){
		double shpenzimi = shpenzo(fromIp, madhesia);
		double teMbetura = limiti - teShpenzuara;
		if(!fromIp.equals(ip) && teMbetura >= shpenzimi) {
			teShpenzuara += shpenzimi;
			shkarkimet +="Shkarkimi nga "+fromIp+" ne "+ip+" me madhesi "+madhesia+" GB shpenzoi "+shpenzimi+" GB\n";
			return true;
		}
		if(fromIp.equals(ip)){
			shkarkimet +="Nuk lejohet shkarkim nga vetvetja\n";
		} else {
			shkarkimet +="Shkarkimi nga "+fromIp+" ne "+ip+" me madhesi "+madhesia+" GB nuk u realizua në mungese te GB: "+(shpenzimi - teMbetura)+"\n";
		}
		return false;
	}
	
	private double shpenzo(String fromIp, int madhesia) {
		String sn = ip.substring(0, ip.lastIndexOf("."));
		String fsn = fromIp.substring(0, fromIp.lastIndexOf("."));
		return sn.equals(fsn) ? madhesia*0.1 : madhesia;
	}
	
	private double shpenzo1(String fromIp, int madhesia) {
		String [] sn = ip.split("\\.");
		String [] fsn = fromIp.split("\\.");
		for(int i=0; i<sn.length-1; i++){
			if(sn[i] != fsn[i]) {
				return madhesia;
			}
		}
		return madhesia * 0.1;
	}
	
	@Override
	public String toString(){
		return kodi+" - "+(premium? "eshte" : "nuk eshte")+" premium: "+ ip;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Shfrytezuesi) {
		//if(obj.getClass() == Shfrytezuesi.class){
			Shfrytezuesi user = (Shfrytezuesi)obj;
			return kodi.equals(user.getKodi());
		}
		return false;
	}
}
public class Semafori
{
	public static void main (String []args){
		char ngjyra = 2201-'V'; 
		final char E_KUQE = 'K';
		final char E_VERDHE = 'V';
		final char E_GJELBER = 'G';
		
		if(ngjyra == E_KUQE) {
			System.out.println("Ndal!");
		} else if (ngjyra == E_VERDHE) {
			System.out.println("Behu gati");
		} else if (ngjyra == E_GJELBER) {
			System.out.println("Nisu");
		} else {
			System.out.println("Ngjyra gabim");
		}
	}
}
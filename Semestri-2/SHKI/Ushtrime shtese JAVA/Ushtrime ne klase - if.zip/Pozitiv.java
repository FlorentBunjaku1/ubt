public class Pozitiv{
	public static void main (String []args){
		
		int x=0;
		if (x>0)
			System.out.println(x+ " eshte pozitiv" );
		else if(x<0)
			System.out.println(x+ " eshte negativ" );
		else {
			System.out.println(x+ " eshte zero" );
		}
	} 
}
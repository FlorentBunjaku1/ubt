public class CiftTek{
	public static void main(String [] args){
		int x = 4;
		if(x == 0){
			System.out.printf("Numri %d eshte zero%n" , x);
		}else if (x%2 == 0){
			System.out.printf("Numri %d eshte cift%n" , x);
		}else{
			System.out.printf("Numri %d eshte tek%n" , x);
		}
	}
}
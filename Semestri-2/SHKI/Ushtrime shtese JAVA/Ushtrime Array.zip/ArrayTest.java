import java.util.Scanner;

public class ArrayTest {
	
	static Scanner scan = new Scanner(System.in);
	
	public static void main(String [] arg) {
		
		System.out.print("Shtyp madhesine e vargut: ");
		int [] numrat = new int[scan.nextInt()];
		
		print(numrat);
		
		popullo(numrat);
		
		print(numrat);
		System.out.println("MIN: "+min(numrat));
		System.out.println("MAX: "+max(numrat));
	}
	
	private static int max(int [] nrs) {
		int max = 0;
		for(int i=0; i< nrs.length; i++) {
			if(i == 0 || nrs[i] > max) {
				max = nrs[i];
			}
		}
		return max;
	}
	
	private static int min(int [] nrs) {
		int min = 0;
		for(int i=0; i< nrs.length; i++) {
			if(i == 0 || nrs[i] < min) {
				min = nrs[i];
			}
		}
		return min;
	}
	
	private static void popullo(int [] nrs) {
		for(int i=0; i< nrs.length; i++) {
			System.out.printf("shtyp elementin ne poziten %d:  ",i);			
			nrs[i] = scan.nextInt();
		}
	}
	
	private static void print(int [] nrs) {
		System.out.println("Elementet e vargut jane: ");
		for(int i=0; i< nrs.length; i++) {
			System.out.printf("numrat[%d] = %d%n",i,nrs[i]);
		}
	}
	
}


import java.util.Scanner;

public class MainTest {
	public static void main(String [] arg) {
		System.out.printf("Madhesia e arg: %d%n", arg.length);
		for(int i=0; i<arg.length; i++) {
			System.out.printf("arg[%d] = %s%n",i, arg[i]);
		}

		Scanner scan = new Scanner(System.in);
		System.out.print("Shtyp fjalen qe kerkon: ");
		String fjala = scan.next();
		int pozita = indexOf(fjala, arg);
		if(pozita == -1) {
			System.out.println(fjala+" nuk ekziston ne varg");
		} else {
			System.out.println(fjala+" ne varg paraqitet ne poziten "+pozita);
		}
	}
	
	private static int indexOf(String fjala, String [] vargu) {
		for(int i=0; i<vargu.length; i++) {
			if(vargu[i].equals(fjala)){
				return i;
			}
		}
		return -1;
	}
}
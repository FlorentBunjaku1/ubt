public class Vetura {
	private String regjistrimi; //RO
	private char llojiKarburantit;//RO
	private int kapaciteti;//RO
	private double shpenzimi;
	private double teShpenzuara;
	private String udhetimet="";
	
	public Vetura(String r, char lk, int k, double sh) {
		regjistrimi = r;
		llojiKarburantit = lk;
		kapaciteti = k;
		shpenzimi = sh;		
	}
	
	public String getRegjistrimi (){
		return regjistrimi;
	}
	
	public char getLlojiKarburantit(){
		return llojiKarburantit;
	}
	
	public int getKapaciteti(){
		return kapaciteti;
	}
	
	public double getShpenzimi(){
		return shpenzimi;
	}
	
	public void setShpenzimi(double sh) {
		shpenzimi = sh;
	}
	
	public double getShpenzimiProporcion(){
		return teShpenzuara / kapaciteti;
	}
	
	public String getUdhetimet(){
		return udhetimet;
	}
	
	public boolean vozitje(String destinacioni, double distanca) {
		double teNevojshme = shpenzimi/100*distanca;		
		double teMbetura = kapaciteti - teShpenzuara;
		//System.out.printf("nevojiten %f, i kemi %f%n",teNevojshme, teMbetura);
		if(teMbetura >= teNevojshme) {
			teShpenzuara += teNevojshme;
			udhetimet += "SUKSES: Vetura me "+regjistrimi+" udhetoi ne "+destinacioni+" kaloi distancen "+distanca+" dhe shpenzoi "+teNevojshme+" litra karburant\n";
			return true;
		} 
		udhetimet += "ERROR: Deshtoi udhetimi i vetures me regjistrim "+regjistrimi+" per ne "+destinacioni+", per arsye se nuk kishte karburant te mjaftueshem, mungonin "+(teNevojshme - teMbetura)+" litra";
		return false;
	}
	
	@Override
	public String toString(){
		return regjistrimi+" - "+llojiKarburantit+" : "+kapaciteti;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Vetura){
			Vetura vetura = (Vetura)obj;
			return regjistrimi.equalsIgnoreCase(vetura.getRegjistrimi());
		}
		return false;
	}
}
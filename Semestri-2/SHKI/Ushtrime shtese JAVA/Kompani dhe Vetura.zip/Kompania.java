public class Kompania{
	private String emri;
	private Vetura[] veturat;
	private int index;
	
	public Kompania(String e, int nr){
		emri = e;
		veturat = new Vetura[nr];
	}
	
	public String shtoVeturen(Vetura vetura) {
		if(vetura == null) {
			return "shtoVetura: Vetura eshte NULL";
		}
		
		if(index >= veturat.length) {
			return "shtoVetura: Nuk ka vend per veturen "+vetura;
		}
		
		if(contains(vetura)) {
			return "shtoVetura: Vetura ekziston "+vetura;
		}
		
		veturat[index++] = vetura;
		return "shtoVetura: U shtua vetura dhe u plotesua vargu "+((double)index/veturat.length*100)+"%";
	}
	
	private boolean contains(Vetura vetura){
		for(int i=0; i<index; i++) {
			if(veturat[i].equals(vetura)) {
				return true;
			}
		}
		return false;
	}
	
	private Vetura gjejVeturen(String regjistrimi) {
		for(int i=0; i<index; i++) {
			if(veturat[i].getRegjistrimi().equalsIgnoreCase(regjistrimi)) {
				return veturat[i];
			}
		}
		return null;
	}
	
	public boolean vozitVeturen(String regjistrimi, String destinacioni, double distanca) {
		Vetura vetura = gjejVeturen(regjistrimi);
		if(vetura != null) {
			return vetura.vozitje(destinacioni, distanca);
		}
		return false;
	}
	
	public Vetura maxVozitje(){
		Vetura max = null;
		for(int i=0; i<index; i++) {
			if(i == 0 || veturat[i].getShpenzimiProporcion() > max.getShpenzimiProporcion()){
				max = veturat[i];
			}
		}
		return max;
	}
	
	public void shfletoVozitjet(){
		System.out.println("SHFLETIMI I VETURAVE");
		for(int i=0; i<index; i++) {
			System.out.println(veturat[i]+"\n==============\n"+veturat[i].getUdhetimet());
		}
	}
	
	public static void main(String [] arg) {
		Kompania komp = new Kompania("UBT Transport", 10);
		System.out.println(komp.shtoVeturen(new Vetura("01-111-AA",'P', 80,7.5)));
		System.out.println(komp.shtoVeturen(new Vetura("05-555-BB",'D', 50,5.5)));
		komp.vozitVeturen("01-111-AA", "Prizren", 70);
		komp.vozitVeturen("01-111-AA", "Gjakove", 65);
		komp.vozitVeturen("01-111-AA", "Graz", 1000);
		komp.vozitVeturen("05-555-BB", "Shkup", 100);
		komp.shfletoVozitjet();
		System.out.println("MAX = "+komp.maxVozitje());
	}
}
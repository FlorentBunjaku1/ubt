public class Zanore{
	public static void main(String [] args){
		char c = 'a';
		
		switch(Character.toLowerCase(c)){
			case 'a':
			case 'A':
			case 'e':
			case 'E':
			case 'i':
			case 'I':
			case 'o':
			case 'O':
			case 'u':
			case 'U':
			case 'y':
			case 'Y':
				System.out.println(c+ " eshte Zanore");
				break;	
			default:
				System.out.println(c+ " nuk eshte Zanore");
		}
	}
	
}
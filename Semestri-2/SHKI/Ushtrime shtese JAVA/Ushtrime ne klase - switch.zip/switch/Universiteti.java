public class Universiteti{
	public static void main(String [] args){
		String uni="UBT";
		
		switch (uni){
			case "UBT" :
			case "UP":
			case "AAB":
			case "Riinvest":
				System.out.println (uni+ " eshte universitet");
				break;
			default:
				System.out.println(uni+" nuk eshte universitet");
		}
	}
}
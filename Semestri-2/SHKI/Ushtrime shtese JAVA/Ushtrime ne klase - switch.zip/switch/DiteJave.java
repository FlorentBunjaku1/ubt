public class DiteJave
{
	public static void main(String [] arg)
	{
		int dita = 2;
		final int E_HENE = 1;
		switch(dita)
		{
			case E_HENE:
				System.out.println("E Hene");
				break;
			case 2:
				System.out.println("E Marte");
				break;
			case 3:
				System.out.println("E Merkure");
				break;
			case 4:
				System.out.println("E Enjte");
				break;
			case 5:
				System.out.println("E Premte");
				break;
			case 6:
				System.out.println("E Shtune");
				break;
			case 7:
				System.out.println("E Diele");
				break;
			default:
				System.out.println(dita+" nuk eshte dite jave");
				break;
		}
		
		System.out.println("Fundi i switch");
	}
}
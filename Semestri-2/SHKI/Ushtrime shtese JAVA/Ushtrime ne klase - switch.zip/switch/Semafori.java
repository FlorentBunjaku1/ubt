public class Semafori{
	public static void main(String [] args){
		char ngjyra = 'V';
		final char eKuqe = 'K';
		final char eVerdhe = 'V';
		final char eGjelbert = 'G';
		
	    switch(ngjyra){			
			case eKuqe:
				System.out.println("NDAL");
				break;
			case eVerdhe:
				System.out.println("BEHU GATI");
				break;
			case eGjelbert:
				System.out.println("NISU");
				break;
			default:
				System.out.println("NGJYRA GABIM");
				break;			
		}
	}
}
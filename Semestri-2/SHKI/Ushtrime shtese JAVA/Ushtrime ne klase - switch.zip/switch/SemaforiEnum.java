public class SemaforiEnum{
	enum Ngjyra {KUQE, VERDHE, GJELBER};
	
	public static void main(String [] args){
		Ngjyra ngjyra = Ngjyra.GJELBER;		
		
	    switch(ngjyra){
			
			case KUQE:
				System.out.println("NDAL");
				break;
			case VERDHE:
				System.out.println("BEHU GATI");
				break;
			case GJELBER:
				System.out.println("NISU");
				break;
		}		
	}
}
public class Printf {
	public static void main(String [] arg){
		String emri = "Deme";
		String mbiemri = "Alija";
		int mosha = 50;
		
		System.out.print(emri+" "+mbiemri+" i ka "+mosha+" vjet\n");
		System.out.printf("%s %S i ka %d vjet%n",emri, mbiemri,mosha);
		
		int x = 12345678;
		System.out.printf("Vlera e x eshte [%( -10d]%n",x);
		
		double d = 1234.565;
		System.out.printf("Vlera e d eshte [%.2f]%n",d);
		
		char chr = 'A';
		System.out.printf("%c si shifer %d%n",chr,(int)chr);
		
		int num = 65;
		System.out.printf("num si dec:%d, si oct:%#o, si hex:%#x%n",num,num,num);
	}
}
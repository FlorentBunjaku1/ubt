public class Konvertimi {
	public static void main(String [] arg){
		int x = 10;
		float f = x;
		System.out.println("X:"+x+", F:"+f);
		
		double d = 10;
		int y = 4;
		double r = d/y;
		System.out.println(d+" / "+y+" = "+r);
		
		double dx = 123.56789;
		int di = (int)dx;
		
		System.out.println(dx+" pjesa e plote "+di);
		
		byte b = (byte)130;
		System.out.println("Vlera e b eshte "+b);
		
		char ch = 'A';
		int chr = ch;
		
		char g = '\u00EB';
		System.out.println(ch+" si shifer "+chr);
		System.out.println(g+" si shifer "+(int)g);

		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
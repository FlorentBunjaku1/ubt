public class ForCount
{
	public static void main(String [] arg)
	{
		for(int count=0; count<10; count++)
		{
			System.out.println(count+1);	
		}
	}
}
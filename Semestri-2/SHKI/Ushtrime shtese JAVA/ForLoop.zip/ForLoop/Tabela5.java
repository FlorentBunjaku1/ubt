public class Tabela5
{
	public static void main(String[] args)
	{
		for(int r = 1; r <=10; r++)
		{
			for(int k = 1; k <= 5; k++)
			{
				System.out.print(k + " * " + r + " = " + (r*k) + "\t");
				
			}
			System.out.println();
		}
	}
}
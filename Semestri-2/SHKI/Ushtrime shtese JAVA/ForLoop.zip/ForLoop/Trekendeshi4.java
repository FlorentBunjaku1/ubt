public class Trekendeshi4
{
	public static void main(String[] arg)
	{
		final int COUNT = 5;
		
		for(int r = 0; r < COUNT; r++)
		{
			for(int h = 0; h < r; h++)
			{
				System.out.print(" ");
			}
			for(int k = 0; k < COUNT-r; k++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
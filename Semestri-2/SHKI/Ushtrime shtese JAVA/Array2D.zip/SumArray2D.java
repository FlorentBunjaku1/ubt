public class SumArray2D {
	public static void main(String [] arg) {
		int [][] nrs = {{1,5},{6,9,4},{3,2,7,10,8}};
		print(nrs);
		System.out.println("SHUMA = "+sum(nrs));
	}
	
	private static void print(int [][] vargu){
		for(int i=0; i<vargu.length; i++) {
			System.out.print(i+": ");
			for(int j=0; j<vargu[i].length; j++) {
				System.out.print(vargu[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	private static int sum(int [][] vargu){
		int shuma = 0;
		for(int i=0; i<vargu.length; i++) {
			for(int j=0; j<vargu[i].length; j++) {
				shuma += vargu[i][j];
			}			
		}
		return shuma;
	}
}
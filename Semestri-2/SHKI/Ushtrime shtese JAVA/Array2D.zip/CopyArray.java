public class CopyArray {
	public static void main(String [] arg) {
		int [] nrs = {1,3,5};
		print(nrs);
		nrs = copyAdd(nrs, 7);
		printForEach(nrs);
	}
	
	/** Metoda per te printuar array duke perdorur for loop te thjeshte*/
	private static void print(int [] vargu) {
		System.out.println("LENGTH: "+vargu.length);
		for(int i=0; i<vargu.length; i++) {
			System.out.println(vargu[i]);
		}
	}
	
	/** Metoda per te printuar array duke perdorur forEach loop*/	
	private static void printForEach(int [] vargu) {
		System.out.println("Length: "+vargu.length);
		for(int nr : vargu) {
			System.out.println(nr);
		}
	}
	
	/** Metoda per te simuluar rritjen e vargut per nje element.
	*   Errite vargun per nje dhe ne fund e shton elementin: el
	*/
	private static int[] copyAdd(int [] vargu, int el) {
		int [] numbers = new int[vargu.length + 1];
		for(int i=0; i<vargu.length; i++) {
			numbers[i] = vargu[i];
		}
		numbers[vargu.length] = el;
		return numbers;
	}
	
}
import java.util.Scanner;

public class CharCount {
	public static void main(String [] arg) {
		Scanner scan = new Scanner(System.in);
		final int COUNT = 26;
		int [] upper = new int[COUNT];
		int [] lower = new int[COUNT];
		int [] numbers = new int[10];
		int symbols = 0;
		System.out.print("Shtyp tekst: ");
		String fjalia = scan.nextLine();
		char[] shkronjat = fjalia.toCharArray();
		for(int i=0; i<shkronjat.length; i++) {
			char shkronja = shkronjat[i];
			if(shkronja >= 'A' && shkronja <= 'Z') {
				upper[shkronja - 'A']++;
			} else if(shkronja >= 'a' && shkronja <= 'z') {
				lower[shkronja - 'a']++;
			} else if(shkronja >= '0' && shkronja <= '9') {
				numbers[shkronja - '0']++;
			} else if(shkronja != ' '){
				symbols++;
			}
		}
		
		for(int i=0; i<upper.length; i++) {
			System.out.println((char)('A'+i)+"="+upper[i]+"\t\t\t"+(char)('a'+i)+"="+lower[i]);
		}
		System.out.println("NUMRA: ");
		for(int i=0; i<numbers.length; i++) {
			System.out.println((char)('0'+i)+"="+numbers[i]);
		}
		System.out.println("Simbole: "+symbols);
	}
}












public class Main {
    public static void main(String[] args) {
        TopologicalSort ts = new TopologicalSort("graph1.txt");
        System.out.println(ts);
    }
}
